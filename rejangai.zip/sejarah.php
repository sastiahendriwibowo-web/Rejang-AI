<?php include "nav.php";?>


    <div class="container mt-5">
        <?php 
        $i=mysqli_fetch_array(mysqli_query($conn,"SELECT * from sejarah where id='1'"));
        echo $i['isi'];
        ?>
    </div>

    <!-- Bootstrap JS and dependencies (jQuery not needed in Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>