<?php include "nav.php";?>
<style>
    body {
        background-color: #333;
    }
</style>
<div style="position:relative; height:90vh; display:flex; justify-content:center; align-items:center;">
    
    <!-- Pseudo-element for background with opacity -->
    <div style="content:''; 
                position:absolute; 
                top:0; 
                left:0; 
                width:100%; 
                height:100%; 
                background-image:url(https://osccdn.medcom.id/images/content/2021/10/26/e22342d2e27e3d8fed17bcb4b88daef6.jpg); 
                background-repeat:no-repeat; 
                background-size:cover; 
                opacity:0.5; 
                z-index:-1;">
        
    </div>
    
    <!-- Form container -->
    <div class="container" align="center" style="background-color:rgba(255, 255, 255, 1); 
                                  padding:20px; 
                                  border-radius:10px; 
                                  box-shadow:0px 4px 10px rgba(0, 0, 0, 0.1);
                                  max-width:500px; 
                                  width:100%;">
        <img src="rejang ai.gif" height="200"><br>
        
        <label>Cari Kata Bahasa Rejang</label>
        
        <div class="input-group mt-3 mb-3">
            <input type="search" class="form-control" id="cek" placeholder="Cari Kata">
            
            <div class="input-group-append">
                <a class="btn btn-primary" onclick="carikata()" id="btncek">Cari</a>
            </div>
        </div>
        
        <div id="hasil"></div>
    </div>
</div>

<!-- Media query for mobile view -->
<style>
    @media (max-width: 768px) {
        .container {
            padding: 10px; /* Reduce padding for smaller screens */
        }

        div[style*="position:relative"] {
            justify-content: flex-start; /* Align the form higher */
            padding-top: 10px; /* Add some space from the top */
        }
    }
</style>


    <!-- Bootstrap JS and dependencies (jQuery not needed in Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery (untuk AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $('#cek').on('keypress', function(e)
    {
        if(e.which == 13) { // 13 adalah kode ASCII untuk Enter
            carikata(); 
        }    
    });
    
        function carikata(){
            var cek = $('#cek').val();
            $('#hasil').html('Mencari...');
            $.ajax({
                url : 'kamus.cari.php',
                method: 'get',
                data : {kata:cek},
                success:function(data){
                    $('#hasil').html(data);
                }
            })
        }
    </script>
</body>

</html>