<?php
// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keyword = $_POST['keyword'];
    $response = $_POST['response'];

    // Query untuk menambahkan data ke tabel
    $stmt = $conn->prepare("INSERT INTO chatbot (keyword, response) VALUES (?, ?)");
    $stmt->bind_param('ss', $keyword, $response);

    if ($stmt->execute()) {
        echo 'Keyword berhasil ditambahkan';
    } else {
        echo 'Gagal menambahkan keyword';
    }

    $stmt->close();
}

$conn->close();
