<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Speech Recognition and Database Search</title>

    <!-- Link ke Font Awesome untuk ikon mikrofon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Tambahkan jQuery dari CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous">
    </script>

    <!-- Tambahkan style untuk sedikit memperindah tampilan -->
    <style>
    body {
        background-color: #333;
    }

    #micIcon {
        font-size: 48px;
        cursor: pointer;
        color: #333;
    }

    #micState {
        font-size: 48px;
        cursor: pointer;
        color: #333;
    }

    .listening {
        color: green;
        animation: pulse 1s infinite;
    }

    @keyframes pulse {
        0% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.1);
        }

        100% {
            transform: scale(1);
        }
    }

    #result {
        resize: none;
    }

    #searchResults {
        margin-top: 20px;
        flex: 1;
        /* Area hasil pencarian mengisi ruang yang tersisa */
    }

    .result-item {
        display: flex;
        align-items: center;
    }

    .result-text {
        margin-right: 20px;
        flex: 1;
        /* Agar teks hasil pencarian tidak melebihi lebar gambar */
    }

    .result-image {
        width: 100%;
        /* Agar gambar responsif */
        height: auto;
    }

    @media (max-width: 600px) {
        .container {
            flex-direction: column;
            /* Stack vertical pada layar kecil */
        }

        #result {
            width: 100%;
            /* Lebar input area 100% pada layar kecil */
        }

        .result-item {
            flex-direction: column;
            /* Stack vertical pada layar kecil */
            align-items: flex-start;
        }

        .result-image {
            max-width: 100%;
            /* Gambar akan mengisi 100% dari kontainer pada layar kecil */
        }
    }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Rejang AI</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="./">Sejarah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kamus">Kamus</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="translate">Terjemah</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Fitur AI
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="speak">Kaganga</a></li>
                        <li><a class="dropdown-item" href="chat">Chatbot</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div style="position:relative; height:90vh; display:flex; justify-content:center; align-items:center;">
    
    <!-- Pseudo-element for background with opacity -->
    <div style="content:''; 
                position:absolute; 
                top:0; 
                left:0; 
                width:100%; 
                height:100%; 
                background-image:url(https://osccdn.medcom.id/images/content/2021/10/26/e22342d2e27e3d8fed17bcb4b88daef6.jpg); 
                background-repeat:no-repeat; 
                background-size:cover; 
                opacity:0.5; 
                z-index:-1;">
        
    </div>
    
    <!-- Form container -->
    <div class="container" align="center" style="background-color:rgba(255, 255, 255, 1); 
                                  padding:20px; 
                                  border-radius:10px; 
                                  box-shadow:0px 4px 10px rgba(0, 0, 0, 0.1);
                                  max-width:500px; 
                                  width:100%;">
        <img src="rejang ai.gif" height="150"><br>
            <div align="center" class="mx-2">
                <div class="btn btn-primary w-100" id="micIcon">
                    <i class="fas fa-microphone text-white"></i>
                </div>
                <div class="btn btn-warning w-100 btn-disabled" id="micState" style="display: none;">
                    <i class="fas fa-headphones text-dark fa-fade"></i>
                </div>
            </div>

            <!-- Area untuk menampilkan hasil rekaman -->
            <textarea id="result" class="form-control" placeholder="Hasil rekaman akan tampil di sini..." rows="1"
                style="border:0px"></textarea>

            <div class="mt-4 row pb-4" id="searchResults"  align="center"></div>

    </div>
</div>

    <script>
    $(document).ready(function() {
    // Cek apakah browser mendukung Web Speech API
    if ('webkitSpeechRecognition' in window) {
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false; // Stop after a single input
        recognition.interimResults = false; // Don't show interim results
        recognition.lang = 'id-ID'; // Set language to Indonesian

        const micIcon = $('#micIcon');
        const micState = $('#micState');
        const resultTextarea = $('#result');
        const searchResults = $('#searchResults');

        // Ketika klik ikon mikrofon, mulai mendengarkan
        micIcon.on('click', function() {
            recognition.start();
            micIcon.addClass('listening'); // Tambah animasi
            micIcon.hide(); // Sembunyikan ikon mikrofon
            micState.show(); // Tampilkan ikon headphone
        });

        // Ketika pengenalan suara dimulai
        recognition.onstart = function() {
            console.log("Mendengarkan...");
        };

        // Ketika pengenalan suara berhasil menangkap suara
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            resultTextarea.val(transcript); // Tampilkan hasil
            const pattern = extractPattern(transcript); // Ekstrak pola dari hasil rekaman
            searchInDatabase(pattern); // Panggil fungsi pencarian dengan pola
        };

        // Ketika pengenalan suara berakhir
        recognition.onend = function() {
            micIcon.removeClass('listening'); // Hapus animasi
            micIcon.show(); // Tampilkan ikon mikrofon kembali
            micState.hide(); // Sembunyikan ikon headphone
            console.log("Pengenalan suara berhenti.");
        };

        // Fungsi untuk mengekstrak pola dari hasil rekaman
        function extractPattern(transcript) {
    // Ambil pola pertama dari hasil rekaman atau setidaknya satu karakter
    const pattern = transcript.trim(); // Hapus spasi ekstra
    return pattern.length > 0 ? pattern : null;
}


        // Fungsi untuk mencari di database menggunakan AJAX jQuery
        function searchInDatabase(query) {
            $.ajax({
                url: 'search.php',
                type: 'GET',
                data: {
                    query: query
                },
                success: function(response) {
                    // Jika data adalah string JSON, parsing diperlukan
                    const data = typeof response === 'string' ? JSON.parse(response) : response;
                    displayResults(data); // Tampilkan hasil jika JSON valid
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error); // Debugging jika terjadi kesalahan
                }
            });
        }

        // Fungsi untuk menampilkan hasil pencarian
        function displayResults(data) {
            searchResults.empty(); // Kosongkan hasil sebelumnya

            if (data.length > 0) {
                // Buat row untuk menampilkan hasil dalam grid dua kolom
                const row = $('<div>').addClass('row');

                $.each(data, function(index, item) {
                    // Buat elemen div col-6 untuk membuat layout dua kolom
                    const col = $('<div>').addClass('col-6 mb-3');

                    // Membuat elemen gambar jika URL gambar tersedia
                    if (item.gambar) {
                        const img = $('<img>').attr('src', 'kaganga/' + item.gambar)
                            .attr('alt', `Gambar hasil untuk ${item.kata}`)
                            .addClass('img-fluid p-2'); // Tambahkan class img-fluid untuk responsif

                        // Membuat elemen teks persentase
                        const percentageText = $('<p>').text(`Kesesuaian: ${item.persentase}%`)
                            .addClass('text-muted'); // Teks dengan warna abu-abu

                        // Tambahkan gambar dan persentase ke dalam kolom
                        col.append(img);
                        //col.append(percentageText);
                    }


                    row.append(col); // Tambahkan kolom ke dalam row
                });

                searchResults.append(row); // Tambahkan row hasil ke DOM
            } else {
                searchResults.text('Tidak ada hasil ditemukan.');
            }
        }

    } else {
        alert("Browser kamu tidak mendukung Web Speech API");
    }
});

    </script>

</body>

</html>