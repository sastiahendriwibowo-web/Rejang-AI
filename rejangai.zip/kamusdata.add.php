<?php

// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah ada data yang dikirim via POST
if (isset($_POST['rejang']) && isset($_POST['indonesia'])) {
    $rejang = $_POST['rejang'];
    $indonesia = $_POST['indonesia'];

    // Query untuk memasukkan data ke tabel 'kamus'
    $sql = "INSERT INTO katadasar_rejang (kata,translate) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $rejang, $indonesia);

    // Eksekusi query
    if ($stmt->execute()) {
        echo "Data berhasil ditambahkan";
    } else {
        echo "Gagal menambahkan data: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>