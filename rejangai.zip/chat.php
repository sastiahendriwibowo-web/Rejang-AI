<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot Sederhana dengan Bootstrap 5.3</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    html,
    body {
        height: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }

    .container {
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .chat-container {
        width: 100%;
        max-width: 100%;
        height: 75vh;
        max-height: 100%;
        display: flex;
        flex-direction: column;
    }

    .chat-box {
        flex: 1;
        overflow-y: auto;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 10px;
        background-color: #f8f9fa;
    }

    .message {
        max-width: 80%;
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 20px;
        position: relative;
        word-wrap: break-word;
    }

    .user {
        background-color: #007bff;
        color: white;
        margin-left: auto;
        text-align: right;
    }

    .bot {
        background-color: #e9ecef;
        color: #333;
        margin-right: auto;
        text-align: left;
    }

    .message::after {
        content: '';
        position: absolute;
        width: 0;
        height: 0;
        border: 10px solid transparent;
    }

    .user::after {
        right: -20px;
        border-left: 10px solid #007bff;
        top: 50%;
        transform: translateY(-50%);
    }

    .bot::after {
        left: -20px;
        border-right: 10px solid #e9ecef;
        top: 50%;
        transform: translateY(-50%);
    }

    .input-group {
        margin-top: auto;
    }

    .input-group input,
    .input-group button {
        border-radius: 0;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Rejang AI</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="kamus">Kamus</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="translate">Terjemah</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Fitur AI
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="speak">Kaganga</a></li>
                        <li><a class="dropdown-item" href="chat">Chatbot</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div style="content:''; 
                position:absolute; 
                top:0; 
                left:0; 
                width:100%; 
                height:100%; 
                background-image:url(https://osccdn.medcom.id/images/content/2021/10/26/e22342d2e27e3d8fed17bcb4b88daef6.jpg); 
                background-repeat:no-repeat; 
                background-size:cover; 
                opacity:0.5; 
                z-index:-1;">
        
    </div>
    <div class="container">
        
        <div class="chat-container">
            <div class="chat-box" id="chat-box">
                <!-- Percakapan akan muncul di sini -->
            </div>
            <div class="input-group mt-3">
                <input type="text" id="message-input"
                    style="border:1px solid gray;border-top-left-radius: 10px;border-bottom-left-radius: 10px;"
                    class="form-control" placeholder="Ketik pesan...">
                <button class="btn btn-primary" style="border-top-right-radius: 10px;border-bottom-right-radius: 10px;"
                    id="send-button"><i class="fas fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies (jQuery not needed in Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery (untuk AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
    $(document).ready(function() {
        // Kirim pesan saat tombol diklik
        $('#send-button').click(function() {
            sendMessage();
        });

        // Kirim pesan saat menekan tombol "Enter"
        $('#message-input').keypress(function(e) {
            if (e.which === 13) {
                sendMessage();
            }
        });

        function sendMessage() {
            var message = $('#message-input').val();
            if (message.trim() !== '') {
                // Tampilkan pesan pengguna di kotak obrolan
                $('#chat-box').append('<div class="message user">' + message + '</div>');
                $('#message-input').val('');

                // Kirim pesan ke server menggunakan AJAX
                $.ajax({
                    url: 'chatbot.php',
                    type: 'POST',
                    data: {
                        message: message
                    },
                    success: function(response) {
                        // Tampilkan respons dari chatbot dengan efek mengetik
                        typeWriterEffect(response);
                    }
                });
            }
        }

        function typeWriterEffect(text) {
            var i = 0;
            var speed = 20; // Kecepatan mengetik dalam milidetik

            // Hapus teks lama jika ada
            $('#chat-box').append('<div class="message bot" id="typing-message"></div>');

            function type() {
                if (i < text.length) {
                    $('#typing-message').append(text.charAt(i));
                    i++;
                    setTimeout(type, speed);
                } else {
                    $('#typing-message').removeAttr('id'); // Hapus id setelah teks selesai
                    $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight); // Scroll otomatis ke bawah
                }
            }

            type(); // Memulai efek mengetik
        }
    });
    </script>

</body>

</html>