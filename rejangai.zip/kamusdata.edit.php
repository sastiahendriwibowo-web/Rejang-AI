<?php

// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah ada data yang dikirim via POST
if (isset($_POST['id']) && isset($_POST['kata']) && isset($_POST['translate'])) {
    $id = $_POST['id'];
    $kata = $_POST['kata'];
    $translate = $_POST['translate'];

    // Query untuk memperbarui data berdasarkan ID
    $sql = "UPDATE katadasar_rejang SET kata = ?, translate = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $kata, $translate, $id);

    // Eksekusi query
    if ($stmt->execute()) {
        echo "Data berhasil diperbarui";
    } else {
        echo "Gagal memperbarui data: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>