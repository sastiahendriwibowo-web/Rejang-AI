<?php
header('Content-Type: application/json');

// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = new mysqli($host, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil input dari JavaScript (hasil rekaman suara yang diekstrak menjadi pola)
$pola = $_GET['query']; // Pola dari rekaman, misalnya "ka"
$keyword = $pola;

// Fungsi untuk menghasilkan kombinasi string dengan panjang minimal 1 dan maksimal 3 huruf
function generate_combinations($keyword) {
    // Batasi panjang keyword menjadi maksimal 10 huruf
    $keyword = substr($keyword, 0, 10);
    
    $length = strlen($keyword);
    $combinations = [];

    // Ambil setiap suku kata dari kata
    for ($i = 0; $i < $length; $i++) {
        // Tambahkan kombinasi satu huruf
        $combinations[] = substr($keyword, $i, 1);
        
        // Tambahkan kombinasi dua huruf
        if ($i + 1 < $length) {
            $combinations[] = substr($keyword, $i, 2);
        }
        
        // Tambahkan kombinasi tiga huruf jika ada
        if ($i + 2 < $length) {
            $combinations[] = substr($keyword, $i, 3);
        }
    }

    // Hilangkan kombinasi duplikat jika ada
    return array_unique($combinations);
}




// Panggil fungsi untuk mendapatkan kombinasi yang dihasilkan
$combinations = generate_combinations($pola);

// Mulai membuat query SQL untuk mencari pola di database
$sqlQuery = "SELECT * FROM kaganga WHERE ";
$conditions = [];

foreach ($combinations as $combination) {
    $conditions[] = "katakunci = '" . $conn->real_escape_string($combination) . "'";
}

// Gabungkan semua kondisi menggunakan OR (cari salah satu kombinasi)
$sqlQuery .= implode(' OR ', $conditions);

// Eksekusi query
$sql = $conn->query($sqlQuery);

// Inisialisasi array untuk menyimpan hasil
$aksara = [];

if ($sql->num_rows > 0) {
    // Mengambil hasil pencarian dan menyimpan dalam array
    while ($row = $sql->fetch_assoc()) {
        $kata = $row['katakunci'];

        // Menghitung persentase kesesuaian menggunakan similar_text
        similar_text($keyword, $kata, $percent);

        $aksara[] = array(
            'kata' => $kata,
            'gambar' => $row['gambar'],
            'persentase' => round($percent, 2) // Menyimpan persentase kesesuaian
        );
    }
}

// Mengembalikan hasil dalam bentuk JSON
echo json_encode($aksara);

// Tutup koneksi
$conn->close();
?>