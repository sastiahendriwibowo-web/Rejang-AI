<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejang AI</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <nav class="navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="#"></a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                        <a class="nav-link" href="sejarahdata">Data Sejarah</a>
                    </li>
                <li class="nav-item">
                    
                    <a class="nav-link" href="kamusdata">Data Kamus</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="chatdata">Data Chatbot</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-2">
        <button class="btn btn-primary mt-3 mb-3" data-bs-toggle="modal" data-bs-target="#addKeywordModal">Tambah Keyword</button>
        <div class="table-responsive" id="chatdata">
            <!-- Tempat data chat -->
        </div>

        <!-- Tombol untuk membuka modal -->
        

        <!-- Modal Bootstrap -->
        <div class="modal fade" id="addKeywordModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addKeywordForm">
                            <div class="mb-3">
                                <label for="keyword" class="form-label">Keyword</label>
                                <input type="text" class="form-control" id="keyword" name="keyword" required>
                            </div>
                            <div class="mb-3">
                                <label for="response" class="form-label">Response</label>
                                <textarea class="form-control" id="response" name="response" rows="3" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery (untuk AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function(){
            // Memuat data chat saat halaman dimuat
            chatdata();

            // Fungsi untuk mengambil data chat
            function chatdata(){
                $.ajax({
                    url: 'chat.list.php',
                    type: 'GET', 
                    success: function(data){
                        $('#chatdata').html(data);
                    },
                    error: function(xhr, status, error){
                        console.log('Error: ' + error);
                        $('#chatdata').html('<p>Error loading chat data.</p>');
                    }
                });
            }

            // Menangani form submit dengan AJAX
            $('#addKeywordForm').on('submit', function(e){
                e.preventDefault(); // Mencegah reload halaman

                var keyword = $('#keyword').val();
                var response = $('#response').val();

                $.ajax({
                    url: 'add_keyword.php',
                    type: 'POST',
                    data: {
                        keyword: keyword,
                        response: response
                    },
                    success: function(data){
                        alert('Keyword berhasil ditambahkan');
                        $('#addKeywordForm')[0].reset(); 
                        $('#addKeywordModal').modal('hide'); // Tutup modal
                        
                        chatdata(); // Reload data chat setelah menambahkan
                    },
                    error: function(xhr, status, error){
                        alert('Gagal menambahkan keyword: ' + error);
                    }
                });
            });
        });
    </script>
</body>

</html>
