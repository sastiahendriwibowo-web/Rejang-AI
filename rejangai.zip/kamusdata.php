<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejang AI</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <nav class="navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Rejang AI</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                        <a class="nav-link" href="sejarahdata">Data Sejarah</a>
                    </li>
                <li class="nav-item">
                    <a class="nav-link" href="kamusdata">Data Kamus</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="chatdata">Data Chatbot</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-2">
        <button class="btn btn-primary mt-3 mb-3" data-bs-toggle="modal" data-bs-target="#addKeywordModal">Tambah Kata</button>
        
        <!-- Tabel Dinamis -->
        <div class="table-responsive">
            <table class="table table-bordered" id="keywordTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Rejang</th>
                        <th>Indonesia</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="keywordBody">
                    <!-- Data akan di-load di sini dengan AJAX -->
                </tbody>
            </table>
        </div>

        <!-- Modal Bootstrap -->
        <div class="modal fade" id="addKeywordModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Kata Terjemah</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addKeywordForm">
                            <div class="mb-3">
                                <label for="rejang" class="form-label">Kata Rejang</label>
                                <input type="text" class="form-control" id="rejang" name="rejang" required>
                            </div>
                            <div class="mb-3">
                                <label for="indonesia" class="form-label">Kata Indonesia</label>
                                <input type="text" class="form-control" id="indonesia" name="indonesia" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Modal Bootstrap untuk Edit Kata -->
        <div class="modal fade" id="editKeywordModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Kata Terjemah</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="editKeywordForm">
                            <input type="hidden" id="edit-id" name="id">
                            <div class="mb-3">
                                <label for="edit-kata" class="form-label">Kata Rejang</label>
                                <input type="text" class="form-control" id="edit-kata" name="kata" required>
                            </div>
                            <div class="mb-3">
                                <label for="edit-translate" class="form-label">Kata Indonesia</label>
                                <input type="text" class="form-control" id="edit-translate" name="translate" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery (untuk AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    

    <script>
        // Load data dari server
        function loadKeywords() {
            $.ajax({
                url: 'kamusdata.list.php', // URL untuk mendapatkan data kata terjemah
                method: 'GET',
                success: function(response) {
                    $('#keywordBody').html(response);
                }
            });
        }

        // Panggil fungsi loadKeywords saat halaman dimuat
        $(document).ready(function() {
            loadKeywords();

            // Tambah data dengan AJAX
            $('#addKeywordForm').on('submit', function(e) {
                e.preventDefault();
                var rejang = $('#rejang').val();
                var indonesia = $('#indonesia').val();

                $.ajax({
                    url: 'kamusdata.add.php', // URL untuk menambahkan kata terjemah
                    method: 'POST',
                    data: { rejang: rejang, indonesia: indonesia },
                    success: function(data) {
                        // Kosongkan form dan tutup modal
                        $('#addKeywordForm')[0].reset();
                        $('#addKeywordModal').modal('hide');
                        
                        // Refresh tabel
                        alert(data)
                        loadKeywords();
                    }
                });
            });

            // Hapus data dengan AJAX
            $(document).on('click', '.delete-keyword', function() {
                var id = $(this).data('id');
                if(confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                    $.ajax({
                        url: 'kamusdata.hapus.php', // URL untuk menghapus kata terjemah
                        method: 'POST',
                        data: { id: id },
                        success: function(response) {
                            // Refresh tabel
                            alert(response);
                            loadKeywords();
                        }
                    });
                }
            });
        });
        
        // Menangani tombol "Edit"
    $(document).on('click', '.edit-keyword', function() {
        var id = $(this).data('id');
        var kata = $(this).data('kata');
        var translate = $(this).data('translate');

        // Masukkan data yang akan di-edit ke dalam form modal
        $('#edit-id').val(id);
        $('#edit-kata').val(kata);
        $('#edit-translate').val(translate);

        // Tampilkan modal edit
        $('#editKeywordModal').modal('show');
    });

    // Proses edit data dengan AJAX
    $('#editKeywordForm').on('submit', function(e) {
        e.preventDefault();
        var id = $('#edit-id').val();
        var kata = $('#edit-kata').val();
        var translate = $('#edit-translate').val();

        $.ajax({
            url: 'kamusdata.edit.php',  // URL untuk menyimpan perubahan data
            method: 'POST',
            data: { id: id, kata: kata, translate: translate },
            success: function(data) {
                // Kosongkan form dan tutup modal
                $('#editKeywordForm')[0].reset();
                $('#editKeywordModal').modal('hide');
                alert(data);
                // Refresh tabel
                loadKeywords();
            }
        });
    });
    </script>
</body>

</html>
