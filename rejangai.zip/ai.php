<?php include "nav.php"; ?>
<div class="container-fluid mt-4">
    <ul class="nav nav-tabs nav-justified">
        <li class="nav-item">
            <a class="nav-link active" href="#chatbot" data-toggle="tab">Chatbot</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#pengenalan-suara" data-toggle="tab">Pengenalan Suara</a>
        </li>
    </ul>

    <div class="tab-content" style="border: 1px solid #ddd; border-radius:5px">
        <div class="tab-pane active p-2" id="chatbot">
            <!-- Chatbot content goes here -->
        </div>
        <div class="tab-pane p-2" id="pengenalan-suara">
            <div class="row">
                <div class="col-lg-6">
                    <button id="click_to_convert" class="btn btn-primary"><i
                            class="fas fa-microphone fa-2x"></i></button><br>
                    <textarea id="convert_text" class="form-control"></textarea>
                </div>
                <div class="col-lg-6">
                    <div id="recognized_text" class="form-control">
                        Hasil
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
    crossorigin="anonymous"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="speech.js"></script>
</body>