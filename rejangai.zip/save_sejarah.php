<?php
// Database configuration
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if data is sent via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the 'isiSejarah' data from the AJAX request
    $isiSejarah = $_POST['isiSejarah'];

    // Prepare an SQL statement to insert the data into the 'sejarah' table
    $stmt = $conn->prepare("UPDATE sejarah set isi= (?) where id='1'");

    // Bind the 'isiSejarah' value to the SQL statement
    $stmt->bind_param('s', $isiSejarah);

    // Execute the SQL statement
    if ($stmt->execute()) {
        // Success response
        echo 'Data berhasil disimpan ke database.';
    } else {
        // Error response
        echo 'Terjadi kesalahan saat menyimpan ke database: ' . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo 'Metode tidak valid';
}

// Close the database connection
$conn->close();
?>
