$(document).ready(function() {
    // Cek apakah browser mendukung Web Speech API
    if ('webkitSpeechRecognition' in window) {
      const recognition = new webkitSpeechRecognition();
      recognition.continuous = false; // Stop after a single input
      recognition.interimResults = false; // Don't show interim results
      recognition.lang = 'id-ID'; // Set language to Indonesian
  
      const micIcon = $('#micIcon');
      const micState = $('#micState');
      const resultTextarea = $('#result');
      const searchResults = $('#searchResults');
  
      // Ketika klik ikon mikrofon, mulai mendengarkan
      micIcon.on('click', function() {
        recognition.start();
        micIcon.addClass('listening'); // Tambah animasi
        micState.removeClass('fa-microphone').addClass('fa-microphone-alt'); // Ganti ikon
      });
  
      // Ketika pengenalan suara dimulai
      recognition.onstart = function() {
        console.log("Mendengarkan...");
      };
  
      // Ketika pengenalan suara berhasil menangkap suara
      recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        resultTextarea.val(transcript); // Tampilkan hasil
        const pattern = extractPattern(transcript); // Ekstrak pola dari hasil rekaman
        searchInDatabase(pattern); // Panggil fungsi pencarian dengan pola
      };
  
      // Ketika pengenalan suara berakhir
      recognition.onend = function() {
        micIcon.removeClass('listening'); // Hapus animasi
        micState.removeClass('fa-microphone-alt').addClass('fa-microphone'); // Kembali ke ikon awal
        console.log("Pengenalan suara berhenti.");
      };
  
      // Fungsi untuk mengekstrak pola dari hasil rekaman
      function extractPattern(transcript) {
        // Ambil dua karakter pertama sebagai pola
        const pattern = transcript.slice(0, 2); // Misalnya "ka" dari "kakakaka"
        return pattern;
      }
  
      // Fungsi untuk mencari di database menggunakan AJAX jQuery
      function searchInDatabase(query) {
        $.ajax({
          url: 'search.php',
          type: 'GET',
          data: {query: query},
          success: function(data) {
            displayResults(data); // Tampilkan hasil jika JSON valid
          },
        });
      }
  
      // Fungsi untuk menampilkan hasil pencarian
      function displayResults(data) {
        searchResults.empty(); // Kosongkan hasil sebelumnya
        if (data.length > 0) {
          $.each(data, function(index, item) {
            const div = $('<div>').text(item.aksara);
            searchResults.append(div);
          });
        } else {
          searchResults.text('Tidak ada hasil ditemukan.');
        }
      }
    } else {
      alert("Browser kamu tidak mendukung Web Speech API");
    }
  });
  