<?php

// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil semua data dari tabel 'kamus'
$sql = "SELECT * FROM katadasar_rejang order by kata asc";
$result = $conn->query($sql);

// Jika ada hasil, tampilkan dalam bentuk HTML
if ($result->num_rows > 0) {
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$no}</td>
                <td>{$row['kata']}</td>
                <td>{$row['translate']}</td>
                <td>
                 <button class='btn btn-primary edit-keyword' data-id='{$row['id']}' data-kata='{$row['kata']}' data-translate='{$row['translate']}'>
                        Edit
                    </button>
                    <button class='btn btn-danger delete-keyword' data-id='{$row['id']}'>
                        Hapus
                    </button>
                    
                </td>
              </tr>";
        $no++;
    }
} else {
    echo "<tr><td colspan='4' class='text-center'>Tidak ada data</td></tr>";
}

$conn->close();
?>