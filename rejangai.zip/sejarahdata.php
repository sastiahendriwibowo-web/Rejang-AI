<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Sejarah - Rejang AI</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Quill CSS -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <style>
        #editor {
            height: 300px;
            background-color: white;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand navbar-dark text-dark bg-darkon">
        <div class="container">
            <a class="navbar-brand" href="#">Rejang AI</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="sejarahdata">Data Sejarah</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kamusdata">Data Kamus</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="chatdata">Data Chatbot</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4"> 
    <?php
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;
?>
        <h2>Edit Sejarah</h2>
        <form id="editSejarahForm">
            <div class="mb-3">
                <label for="isiSejarah" class="form-label">Isi Sejarah</label>
                <div id="editor">
                    <p>
                        <?php 
                        $i=mysqli_fetch_array(mysqli_query($conn,"SELECT * from sejarah where id='1'"));
                        echo $i['isi'];
                        ?>
                    </p>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery (for AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Quill JS -->
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

    <script>
        // Initialize Quill editor with image support
        var quill = new Quill('#editor', {
            theme: 'snow',
            placeholder: 'Edit isi sejarah...',
            modules: {
                toolbar: [
                    [{ header: [1, 2, false] }],
                    ['bold', 'italic', 'underline'],
                    ['link', 'blockquote', 'code-block'],
                    [{ list: 'ordered' }, { list: 'bullet' }],
                    ['image']  // Add the image button to the toolbar
                ]
            }
        });

        // Image upload handler
        function imageHandler() {
            var input = document.createElement('input');
            input.setAttribute('type', 'file');
            input.setAttribute('accept', 'image/*');
            input.click();

            input.onchange = function () {
                var file = input.files[0];
                var reader = new FileReader();

                reader.onload = function (e) {
                    var range = quill.getSelection();
                    quill.insertEmbed(range.index, 'image', e.target.result);  // Insert image
                };
                reader.readAsDataURL(file);  // Read image as Base64
            };
        }

        // Override the image button click event
        quill.getModule('toolbar').addHandler('image', imageHandler);

        // Form submission
        $('#editSejarahForm').on('submit', function(e) {
            e.preventDefault();

            // Get content from Quill editor
            const isiSejarah = quill.root.innerHTML;

            // Send data to PHP via AJAX
            $.ajax({
                url: 'save_sejarah.php',  // PHP file to handle the data
                type: 'POST',
                data: { isiSejarah: isiSejarah },
                success: function(response) {
                    console.log('Server response:', response); // You can display this to the user or handle it
                    alert('Data berhasil disimpan!');
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                }
            });
        });
    </script>
</body>

</html>
