<?php
// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

// Buat koneksi
$conn = new mysqli($host, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk mencari respons berdasarkan kata kunci
function getResponse($conn, $keywords) {
    // Urutkan kata kunci dari yang paling panjang ke yang paling pendek
    usort($keywords, function($a, $b) {
        return strlen($b) - strlen($a);
    });

    // Cek setiap kata kunci di database
    foreach ($keywords as $keyword) {
        $keyword = $conn->real_escape_string($keyword);
        $query = "SELECT response FROM chatbot WHERE keyword LIKE '%$keyword%'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row['response'];
        }
    }

    // Jika tidak ada yang cocok, kembalikan respons default
    return "Maaf, saya belum memiliki informasi tentang hal tersebut.";
}

// Ambil pesan dari request
if (isset($_POST['message'])) {
    $userMessage = $conn->real_escape_string($_POST['message']);

    // Simpan pesan pengguna ke database
    $query = "INSERT INTO messages (message, sender) VALUES ('$userMessage', 'user')";
    $conn->query($query);

    // Buat daftar kata kunci
    $keywords = explode(' ', strtolower($userMessage)); // Pisahkan berdasarkan spasi
    $keywords[] = strtolower($userMessage); // Tambahkan seluruh pesan sebagai kata kunci

    // Cari respons berdasarkan kata kunci
    $response = getResponse($conn, $keywords);

    // Simpan respons dari chatbot ke database
    $query = "INSERT INTO messages (message, sender) VALUES ('$response', 'bot')";
    $conn->query($query);

    // Kirim respons kembali ke pengguna
    echo $response;
}

$conn->close();
?>