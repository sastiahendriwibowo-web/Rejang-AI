<?php

// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;


?>

<div class="list-group my-3">
    <?php 
    $chat=mysqli_query($conn,"SELECT * from chatbot order by id asc");
    while($c=mysqli_fetch_array($chat))
    {
        ?>
        <div class="list-group-item">
            <small>Keywords : <?=$c['keyword'];?></small>
            <p><?=$c['response'];?></p>
            <button class="btn btn-danger btn-sm delete-btn" data-id="<?=$c['id'];?>">Hapus</button>
        </div>
        <?php
    }
    ?>
</div>

<script>
    $(document).ready(function(){
        // Ketika tombol hapus diklik
        $('.delete-btn').on('click', function(){
            var id = $(this).data('id');  // Ambil ID dari data-id tombol
            if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                $.ajax({
                    url: 'delete_chat.php', // File PHP untuk menghapus data
                    type: 'POST',
                    data: { id: id }, // Kirim ID melalui AJAX
                    success: function(response) {
                        alert(response); // Tampilkan pesan hasil
                        location.reload(); // Refresh halaman setelah menghapus
                    },
                    error: function(xhr, status, error){
                        alert('Gagal menghapus data: ' + error);
                    }
                });
            }
        });
    });
</script>
