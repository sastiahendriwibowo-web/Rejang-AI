<?php
// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;
// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Query untuk menghapus data berdasarkan ID
    $stmt = $conn->prepare("DELETE FROM chatbot WHERE id = ?");
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        echo 'Data berhasil dihapus';
    } else {
        echo 'Gagal menghapus data';
    }

    $stmt->close();
}

$conn->close();
?>
