click_to_convert.addEventListener('click', function() {
    var speech = true;
    window.SpeechRecognition = window.webkitSpeechRecognition;
    const recognition = new window.SpeechRecognition(); // Use the new keyword
    recognition.interimResults = true;

    recognition.addEventListener('result', e => {
        const transcript = Array.from(e.results)
            .map(result => result[0])
            .map(result => result.transcript);

        convert_text.innerHTML = transcript;

        if(transcript=='reset'){
            convert_text.innerHTML = '';
        }
        else if(transcript=='stop'){
            recognition.stop();
            convert_text.innerHTML = '';
            click_to_convert.innerHTML = "<i class='fas fa-microphone fa-2x'></i>";
            speech = false;
        }
    });

    recognition.addEventListener('end', function() {
        if (speech == true) {
            recognition.stop();
            click_to_convert.innerHTML = "<i class='fas fa-microphone fa-2x'></i>";
            speech = false;
        }
    });

    if (speech == true) {
        recognition.start();
        click_to_convert.innerHTML = "<i class='fas fa-headphones fa-fade fa-2x' style='--fa-animation-duration: 2s; --fa-fade-opacity: 0.6;'></i>";
    } else {
        click_to_convert.innerHTML = "<i class='fas fa-microphone fa-2x'></i>";
    }
});