<?php include "nav.php";?>


    <div class="container">
        <div align="center" class="mt-4" style="font-size:20pt">
            Rejang AI merupakan aplikasi untuk mengenal tentang Bahasa dan Budaya Rejang yang terdapat di Provinsi Bengkulu<br>
            <img src="https://rejang-ai.my.id/rejang%20ai.gif" class="img-responsive">
        </div>
    </div>

    <!-- Bootstrap JS and dependencies (jQuery not needed in Bootstrap 5) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>