<?php

// Koneksi ke database
$host = 'localhost';
$dbname = 'beng5632_rejang';
$username = 'beng5632_sastia';
$password = 'sastia@rejang';

$conn = mysqli_connect($host, $username, $password, $dbname) ;

$kata = $_GET['kata'];
$cmd = mysqli_query($conn, "SELECT * FROM katadasar_rejang WHERE kata = '$kata'");

if (mysqli_num_rows($cmd) > 0) {
    echo 'Kata <b>' . $kata . '</b> tersedia di bahasa Rejang';
} else {
    // Jika kata tidak ditemukan, cari kata-kata yang mirip menggunakan SOUNDEX
    $similar_cmd = mysqli_query($conn, "SELECT kata FROM katadasar_rejang WHERE SOUNDEX(kata) = SOUNDEX('$kata') LIMIT 3");
    
    if (mysqli_num_rows($similar_cmd) > 0) {
        $similar_words = [];
        while ($row = mysqli_fetch_assoc($similar_cmd)) {
            $similar_words[] = $row['kata'];
        }
        echo 'Kata <b>' . $kata . '</b> tidak tersedia di bahasa Rejang. Mungkin maksud Anda adalah: ' . implode(', ', $similar_words);
    } else {
        echo 'Kata <b>' . $kata . '</b> tidak tersedia di bahasa Rejang dan tidak ada kata yang mirip ditemukan.';
    }
}
?>